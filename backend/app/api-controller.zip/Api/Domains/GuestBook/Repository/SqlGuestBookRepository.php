<?php

namespace App\Api\Domains\GuestBook\Repository;

use App\Api\Domains\Common\Repository\SqlCommonRepository;

class SqlGuestBookRepository extends SqlCommonRepository implements IGuestBookRepository
{
	public $model; 
	public function __construct()
    {
		parent::__construct('\App\Api\Domains\GuestBook\Model\GuestBook');
		$this->model = $this->getModel();
	}
	
}