<?php

namespace App\Repositories\Auth;

interface IAuthRepository 
{
    
}