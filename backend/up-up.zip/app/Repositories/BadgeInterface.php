<?php
namespace App\Repositories;
interface BadgeInterface 
{
    public function send();
}